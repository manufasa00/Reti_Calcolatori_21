/*
 ============================================================================
 Name        : clientUDP.c
 Author      : Manuel Fasanella Mario Franco
 Description : Client UDP program
 ============================================================================
 */


#include <stdio.h>
#include <string.h>
#include "protocol.h"

//Cleaning WSA
void clearWSA()
{
	WSACleanup();
}

//Initializing WSA
int startupWSA()
{
	WSADATA wd;
	WORD wVersion = MAKEWORD(2, 2);
	int res = WSAStartup(wVersion, &wd);
	if (res != NO_ERROR)
		return -1;
	else
		return 1;
}

//Printing the message (\n incorporated)
void printMSG(char *msg)
{
	printf("%s\n", msg);
}


int main(int argc, char *argv[])
{

	char *addr;   //IP ADDRESS
	int port;
	char *in;	  //Arguments in Input
	char *name;	  //Alias of IP ADDRESS

	//Default case
		if (argc <= 1)
		{
			addr = (char *) malloc (strlen(IP_ADDRESS) * sizeof(IP_ADDRESS)); //Gets default IP
			strcpy(addr, IP_ADDRESS);
			port = PORT; //Gets default PORT
		}
		else
		//IP Address and PORT in arguments case
		{
			in = (char *) malloc (strlen(argv[1]) * sizeof(argv[1]));
			strcpy(in, argv[1]);
			name = strtok(in,":");		     //Getting alias
			port = atoi(strtok(NULL,":"));   //Getting port
		}

	//Startup for client socket
	if (startupWSA() == 1)
	{
		//Translation of alias in address (agruments case)
		if(addr == NULL){
			struct hostent *host;
			host = gethostbyname(name);
			if (host == NULL){
				fprintf(stderr, "gethostbyname() failed.\n");
				exit(EXIT_FAILURE);
			}else{
				struct in_addr* ina = (struct in_addr*) host->h_addr_list[0];
				//printf("Risultato di gethostbyname(%s): %s\n", name, inet_ntoa(*ina));
				addr = (char *) malloc (strlen(inet_ntoa(*ina)) * sizeof(inet_ntoa(*ina))); //Gets default IP
				strcpy(addr,inet_ntoa(*ina));
			}
		}else
		//Default case, translating alias in address
		{
			struct hostent *host;
			struct in_addr address;
			address.s_addr = inet_addr(addr);
			host = gethostbyaddr((char *) &address, 4, AF_INET);
			name = (char *) malloc (strlen(host->h_name) * sizeof(host->h_name));
			strcpy(name, host->h_name);
		}

		//Making Client Socket
		int client_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
		if (client_socket < 0)
		{
			printMSG("Error! Socket creation failed.");
			closesocket(client_socket);
			clearWSA();
			return -1;
		}

		//Building server address
		struct sockaddr_in server;
		struct sockaddr_in fromAddr;

		int fromSize;
		int respStringLen;
		memset(&server, 0, sizeof(server));
		server.sin_family = AF_INET;
		server.sin_port = htons(port);
		server.sin_addr.s_addr = inet_addr(addr);

		//Response phase
		char buf[BUFFERSIZE];
		msg message;

		//Comunication and result phase
		while (1)
		{
			char input[BUFFERSIZE];
			int echoStringLen;

			memset(buf, 0, sizeof(buf));
			memset(input, 0, sizeof(input));

			//Input phase
			printf("======================================================================\n");
			printf("Enter operation: (Formula: operator num1 num2) \n");
			printf("Enter '=' to disconnect.\n");
			fgets(input, BUFFERSIZE, stdin);

			message.operator = getOperator(input);
			echoStringLen = sizeof(input);
			fflush(stdin);

			//Closing phase (checking '=')
			if (message.operator == '=')
			{
				if (sendto(client_socket, input, echoStringLen, 0, (struct
						sockaddr*)&server, sizeof(server)) != echoStringLen)
				{
					printMSG(SEND_ERROR);
					closesocket(client_socket);
					clearWSA();
					return -1;
				}
				printMSG("Disconnected from the server.");
				closesocket(client_socket);
				clearWSA();

				system("pause");
				return 0;
			}

			//Sending phase (message)
			if (sendto(client_socket, input, echoStringLen, 0, (struct
					sockaddr*)&server, sizeof(server)) != echoStringLen)
			{
				printMSG(SEND_ERROR);
				closesocket(client_socket);
				clearWSA();

				return -1;
			}

			//Response phase (message)
			fromSize = sizeof(fromAddr);
			respStringLen = recvfrom(client_socket, buf, echoStringLen, 0, (struct
					sockaddr*)&fromAddr, &fromSize);
			if (server.sin_addr.s_addr != fromAddr.sin_addr.s_addr){
				printMSG(RECV_ERROR);
				closesocket(client_socket);
				clearWSA();

				return -1;
			}

			//Printing result
			printf("Received result by server %s, ip %s: %s\n", name, addr, buf);

		}
	}
	else
	{
		printMSG("Error! Socket startup failed.");
		clearWSA();

		return -1;
	}

	system("pause");
	return 0;
}
