/*
 ============================================================================
 Name        : protocol.h
 Author      : Mario Franco Manuel Fasanella
 Description : Application protocol UDP
 ============================================================================
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif

#define IP_ADDRESS "127.0.0.1"
#define PORT 56700
#define BUFFERSIZE 1024
#define SEND_ERROR "Error! sendto() failed."
#define RECV_ERROR "Error! recvfrom() failed."

//Gets the operator of the equation (first element)
char getOperator(char string[])
{
	return string[0];
}

//Gets the first value of the equation
int getFirstValue(char string[])
{
	char first[BUFFERSIZE];
	int stringPos = 2;
	int numPos = 0;
	while (string[stringPos] != ' ')
	{
		first[numPos] = string[stringPos];
		stringPos++;
		numPos++;
	}

	first[numPos] = '\0';
	return atoi(first);
}

//Gets the second value of the equation
int getSecondValue(char string[])
{
	char second[BUFFERSIZE];
	int stringPos = 2;
	int numPos = 0;
	int numPlusPos = 0;

	while (string[stringPos] != ' ')
	{
		stringPos++;
	}
	numPlusPos = stringPos+1;

	while (string[numPlusPos] != '\0')
	{
		second[numPos] = string[numPlusPos];
		numPlusPos++;
		numPos++;
	}

	second[numPlusPos] = '\0';
	return atoi(second);
}

typedef struct msg
{
	char operator;
	int first;
	int second;
}msg;


#endif /* PROTOCOL_H */
