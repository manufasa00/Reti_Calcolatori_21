/*
 ============================================================================
 Name        : serverUDP.c
 Author      : Manuel Fasanella Mario Franco
 Description : Server UDP program
 ============================================================================
 */

#include <stdio.h>
#include <string.h>
#include "protocol.h"


//Cleaning WSA
void clearWSA()
{
	WSACleanup();
}

//Initializing WSA
int startupWSA()
{
	WSADATA wd;
	WORD wVersion = MAKEWORD(2, 2);
	int res = WSAStartup(wVersion, &wd);
	if (res != NO_ERROR)
		return -1;
	else
		return 1;
}

//Operation SUM
int add(int a, int b)
{
	return a + b;
}

//Operation MULTIPLY
int mult(int a, int b)
{
	return a * b;
}

//Operation SUBTRACTION
int sub(int a, int b)
{
	return a - b;
}

//Printing the message (\n incorporated)
void printMSG(char *msg)
{
	printf("%s\n", msg);
}

//Operation DIVISION (format double)
double division(double a, double b)
{
	if (b != 0){
		return a / b;
	}
	else
	{
		printMSG("Error! Division failed.");
		return 0;
	}
}


//Returns the result of the operation chosen
double chooseOperation(char op, int v1, int v2)
{
	double result = 0;

	//Switch case to check the operator
	switch(op)
	{
	case '+':
		result = add(v1, v2);
		break;

	case '*':
		result = mult(v1, v2);
		break;

	case '-':
		result = sub(v1, v2);
		break;

	case '/':
		result = division(v1, v2);
		break;

	case '=':
		break;
	}
	return result;
}

int main(int argc, char *argv[])
{

	char *addr = NULL;	//IP ADDRESS
	int port;
	char *in;      //Arguments in Input
	char *name;    //Alias of IP ADDRESS

	//Default case
	if (argc <= 1)
	{
		addr = (char *) malloc (strlen(IP_ADDRESS) * sizeof(IP_ADDRESS)); //Gets default IP
		strcpy(addr, IP_ADDRESS);
		port = PORT; //Gets default PORT
	}
	else
	//IP Address and PORT in arguments case
	{
		in = (char *) malloc (strlen(argv[1]) * sizeof(argv[1]));
		strcpy(in, argv[1]);
		name = strtok(in,":");   //Getting alias
		port = atoi(strtok(NULL,":"));    //Getting port
	}

	//Startup for server socket
	if (startupWSA() == 1)
	{

		//Making Server Socket
		int sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);

		//Building server address
		struct sockaddr_in sad;
		memset(&sad, 0, sizeof(sad));

		//Translation of alias in address (agruments case)
		if(addr == NULL){
			struct hostent *host;
			host = gethostbyname(name);
			if (host == NULL){
				fprintf(stderr, "gethostbyname() failed.\n");
				exit(EXIT_FAILURE);
			}else{
				struct in_addr* ina = (struct in_addr*) host->h_addr_list[0];
				//printf("Risultato di gethostbyname(%s): %s\n", name, inet_ntoa(*ina));
				addr = (char *) malloc (strlen(inet_ntoa(*ina)) * sizeof(inet_ntoa(*ina))); //Gets default IP
				strcpy(addr,inet_ntoa(*ina));
			}
		}

		sad.sin_family = AF_INET;
		sad.sin_port = htons(port);
		sad.sin_addr.s_addr = inet_addr(addr);

		//Binding phase
		if ((bind(sock, (struct sockaddr*) &sad, sizeof(sad))) < 0)
		{
			printMSG("Error! Server bind failed.");
			closesocket(sock);
			clearWSA();

			system("pause");
			return -1;
		}

		printf("Server started! IPADDRESS: %s PORT: %d\n", addr, port);

		//Listening phase (1 because always on listen)
		while (1)
		{

			//Preparing server to receive client messages
			struct sockaddr_in cad;
			msg message;
			int client_length;
			char operator;
			double resp;

			//Comunication and calculation phase
			while (1)
			{
				client_length = sizeof(cad);
				char result[BUFFERSIZE];
				int recvMsgSize = recvfrom(sock, result, BUFFERSIZE, 0, (struct sockaddr*)&cad, &client_length);
				if (recvMsgSize < 0)
				{
					printMSG(RECV_ERROR);
					closesocket(sock);
					clearWSA();

					system("pause");
				}

				//Getting data from result
				message.operator = getOperator(result);
				message.first = getFirstValue(result);
				message.second = getSecondValue(result);

				//Getting client name and ip address
				struct hostent *hostClient;
				hostClient = gethostbyaddr((char *)&cad.sin_addr, sizeof(struct in_addr), AF_INET);
				char* client_name = hostClient->h_name;
				char *ip = inet_ntoa(cad.sin_addr);

				printf("Requested operation '%c %d %d' dal client %s, ip %s\n", message.operator, message.first, message.second, client_name, ip);

				operator = message.operator;

				//Case for exit
				if (operator == '='){
					break;
				}

				//Case for the division in which we print a result format double to two decimal digits
				if (operator == '/'){
					resp = chooseOperation(operator, message.first, message.second);
					sprintf(result, "%d %c %d = %.2f", message.first, message.operator, message.second, resp);
				}else{
					//Case for the other operators in which we print an int
					resp = chooseOperation(operator, message.first, message.second);
					sprintf(result, "%d %c %d = %d", message.first, message.operator, message.second, (int)resp);
				}

				//Sending calculation response to the client
				if (sendto(sock, result, strlen(result), 0,  (struct sockaddr *)&cad, sizeof(cad)) != strlen(result))
				{
					printMSG(SEND_ERROR);
					closesocket(sock);
					clearWSA();

					system("pause");
					return -1;
				}

			}
		}
	}
	else
	{
		printMSG("Error! Socket startup failed.");
		clearWSA();

		system("pause");
		return -1;
	}



	system("pause");
	return 0;
}


