/*
 ============================================================================
 Name        : serverTCP.c
 Author      : Mario Franco Manuel Fasanella
 Description : Server TCP program
 ============================================================================
 */

#include <stdio.h>
#include <winsock2.h>
#include <string.h>
#include <ctype.h>
#include "protocol.h"

//Cleaning WSA
void clearWSA()
{
	WSACleanup();
}

//Initializing WSA
int startupWSA()
{
	WSADATA wd;
	WORD wVersion = MAKEWORD(2, 2);
	int res = WSAStartup(wVersion, &wd);
	if (res != NO_ERROR)
		return -1;
	else
		return 1;
}

//Operation SUM
int add(int a, int b)
{
	return a + b;
}

//Operation MULTIPLY
int mult(int a, int b)
{
	return a * b;
}

//Operation SUBTRACTION
int sub(int a, int b)
{
	return a - b;
}

//Printing the message (\n incorporated)
void printMSG(char *msg)
{
	printf("%s\n", msg);
}

//Operation DIVISION
int division(int a, int b)
{
	if (b != 0){
		return a / b;
	}
	else
	{
		printMSG("Error! Division failed.");
		return 0;
	}
}


//Returns the result of the operation chosen
int chooseOperation(char op, int v1, int v2)
{
	int result = 0;

	//Switch case to check the operator
	switch(op)
	{
	case '+':
		result = add(v1, v2);
		break;

	case '*':
		result = mult(v1, v2);
		break;

	case '-':
		result = sub(v1, v2);
		break;

	case '/':
		result = division(v1, v2);
		break;

	case '=':
		break;
	}
	return result;
}

int main(int argc, char *argv[])
{

	char *addr;
	int port;

	//Default case
	if (argc <= 1)
	{
		addr = (char *) malloc (strlen(IP_ADDRESS) * sizeof(IP_ADDRESS)); //Gets default IP
		strcpy(addr, IP_ADDRESS);
		port = PORT; //Gets default PORT
	}
	else
	{
		//Only IP Address in arguments case
		if (strlen(argv[2]) < 0)
		{
			addr = (char *) malloc (strlen(argv[1]) * sizeof(argv[1]));
			strcpy(addr, argv[1]);
			port = PORT;
		}
		//IP Address and PORT in arguments case
		else
		{
			addr = (char *) malloc (strlen(argv[1]) * sizeof(argv[1]));
			strcpy(addr, argv[1]);
			port = atoi(argv[2]);
		}
	}

	//Startup for server socket
	if (startupWSA() == 1)
	{
		int server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

		struct sockaddr_in sad;
		sad.sin_family = AF_INET;
		sad.sin_addr.s_addr = inet_addr(addr);
		sad.sin_port = htons(port);

		//Binding phase
		if (bind(server_socket, (struct sockaddr*) &sad, sizeof(sad)) <0)
		{
			printMSG("Error! Server bind failed.");
			closesocket(server_socket);
			clearWSA();

			system("pause");
			return -1;
		}
		printf("Server started! IPADDRESS: %s PORT: %d\n", addr, port);

		//Listening phase (1 because always on listen)
		while (1)
		{
			if (listen(server_socket, QLEN) < 0)
			{
				printMSG("Error! Listening phase failed.");
				closesocket(server_socket);
				clearWSA();
				system("pause");
				return -1;
			}

			//Accepting phase
			struct sockaddr_in cad;
			int client_socket;
			int client_length;
			printMSG("Waiting for a client to connect...");

			msg message;
			char operator;
			int v1, v2, resp;

			client_length = sizeof(cad);
			if ((client_socket = accept(server_socket, (struct sockaddr *) &cad, &client_length)) < 0)
			{
				printMSG("Error! Connection failed.");
				closesocket(client_socket);
				clearWSA();

				system("pause");
				return -1;
			}

			char checkConn[] = "- Server: Connection accepted!";
			if (send(client_socket, checkConn, strlen(checkConn), 0) < 0)
			{
				printMSG(SEND_ERROR);
				closesocket(client_socket);
				clearWSA();

				system("pause");
				return -1;
			}

			printf("Connection established with %s : %d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));

			//Comunication and calculation phase
			while (1)
			{
				char result[BUFFERSIZE];
				if ((recv(client_socket, &message, sizeof(message), 0)) < 0)
				{
					printMSG(RECV_ERROR);
					closesocket(client_socket);
					clearWSA();

					system("pause");

				}

				operator = message.operator;

				if (operator == '=')
				{
					printMSG("Client disconnected from the server.");
					break;
				}

				v1 = ntohl(message.first);
				v2 = ntohl(message.second);

				resp = chooseOperation(operator, v1, v2);
				sprintf(result, "%d", resp);

				if (send(client_socket, result, strlen(result), 0) < 0)
				{
					printMSG(SEND_ERROR);
					closesocket(client_socket);
					clearWSA();

					system("pause");
					return -1;
				}
			}
		}
	}
	else
	{
		printMSG("Error! Socket startup failed.");
		clearWSA();

		system("pause");
		return -1;
	}

	system("pause");
	return 0;
}

