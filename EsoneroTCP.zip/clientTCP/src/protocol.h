/*
 ============================================================================
 Name        : protocol.h
 Author      : Mario Franco Manuel Fasanella
 Description : Application protocol TCP
 ============================================================================
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define IP_ADDRESS "127.0.0.1"
#define PORT 60000
#define BUFFERSIZE 1024
#define QLEN 5

#define SEND_ERROR "Error! send() failed."
#define RECV_ERROR "Error! recv() failed."

typedef struct msg
{
	char operator;
	int first;
	int second;
}msg;


#endif /* PROTOCOL_H */
