/*
 ============================================================================
 Name        : clientTCP.c
 Author      : Mario Franco Manuel Fasanella
 Description : Client TCP program
 ============================================================================
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <winsock2.h>
#include "protocol.h"

//Cleaning WSA
void clearWSA()
{
	WSACleanup();
}

//Initializing WSA
int startupWSA()
{
	WSADATA wd;
	WORD wVersion = MAKEWORD(2, 2);
	int res = WSAStartup(wVersion, &wd);
	if (res != NO_ERROR)
		return -1;
	else
		return 1;
}

//Printing the message (\n incorporated)
void printMSG(char *msg)
{
	printf("%s\n", msg);
}

//Gets the operator of the equation (first element)
char getOperator(char string[])
{
	return string[0];
}

//Gets the first value of the equation
int getFirstValue(char string[])
{
	char first[BUFFERSIZE];
	int stringPos = 2;
	int numPos = 0;
	while (string[stringPos] != ' ')
	{
		first[numPos] = string[stringPos];
		stringPos++;
		numPos++;
	}

	first[numPos] = '\0';
	return atoi(first);
}

//Gets the second value of the equation
int getSecondValue(char string[])
{
	char second[BUFFERSIZE];
	int stringPos = 2;
	int numPos = 0;
	int numPlusPos = 0;

	while (string[stringPos] != ' ')
	{
		stringPos++;
	}
	numPlusPos = stringPos+1;

	while (string[numPlusPos] != '\0')
	{
		second[numPos] = string[numPlusPos];
		numPlusPos++;
		numPos++;
	}

	second[numPlusPos] = '\0';
	return atoi(second);
}

int main(int argc, char *argv[])
{

	char *addr;
	int port;

	//Default case
		if (argc <= 1)
		{
			addr = (char *) malloc (strlen(IP_ADDRESS) * sizeof(IP_ADDRESS)); //Gets default IP
			strcpy(addr, IP_ADDRESS);
			port = PORT; //Gets default PORT
		}
		else
		{
			//Only IP Address in arguments case
			if (strlen(argv[2]) < 0)
			{
				addr = (char *) malloc (strlen(argv[1]) * sizeof(argv[1]));
				strcpy(addr, argv[1]);
				port = PORT;
			}
			//IP Address and PORT in arguments case
			else
			{
				addr = (char *) malloc (strlen(argv[1]) * sizeof(argv[1]));
				strcpy(addr, argv[1]);
				port = atoi(argv[2]);
			}
		}

	//Startup for client socket
	if (startupWSA() == 1)
	{

		int client_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (client_socket < 0)
		{
			printMSG("Error! Socket creation failed.");
			closesocket(client_socket);
			clearWSA();
			return -1;
		}

		struct sockaddr_in server;
		memset(&server, 0, sizeof(server));
		server.sin_family = AF_INET;
		server.sin_addr.s_addr = inet_addr(addr);
		server.sin_port = htons(port);

		//Connection phase
		if (connect(client_socket, (struct sockaddr*) &server, sizeof(server)) < 0)
		{
			printMSG("Error! Connection failed.");
			closesocket(client_socket);
			clearWSA();
			return -1;
		}

		//Response phase (connection)
		char buf[BUFFERSIZE];
		msg message;

		int data = 0;
		if ((data = recv(client_socket, buf, BUFFERSIZE, 0)) < 0)
		{
			printMSG(RECV_ERROR);
			closesocket(client_socket);
			clearWSA();
			return -1;
		}
		printf("- Server: %s\n", buf);

		//Comunication and result phase
		while (1)
		{
			char input[BUFFERSIZE];
			memset(buf, 0, sizeof(buf));
			memset(input, 0, sizeof(input));

			//Input phase
			printf("======================================================================\n");
			printf("Enter operation: (Formula: operator num1 num2) \n");
			printf("Enter '=' to disconnect.\n");
			fgets(input, BUFFERSIZE, stdin);
			message.operator = getOperator(input);
			message.first = htonl(getFirstValue(input));
			message.second = htonl(getSecondValue(input));
			fflush(stdin);

			//Closing phase (checking '=')
			if (message.operator == '=')
			{
				if ((send(client_socket, &message, sizeof(message), 0)) < 0)
				{
					printMSG(SEND_ERROR);
					closesocket(client_socket);
					clearWSA();
					return -1;
				}
				printMSG("Disconnected from the server.");
				closesocket(client_socket);
				clearWSA();

				system("pause");
				return 0;
			}

			//Sending phase (message)
			if ((send(client_socket, &message, sizeof(message), 0)) < 0)
			{
				printMSG(SEND_ERROR);
				closesocket(client_socket);
				clearWSA();

				return -1;
			}

			//Response phase (message)
			if ((data = recv(client_socket, buf, BUFFERSIZE, 0)) < 0)
			{
				printMSG(RECV_ERROR);
				closesocket(client_socket);
				clearWSA();

				return -1;
			}

			//Printing result
			printf("- Server: result => %s\n", buf);
		}
	}
	else
	{
		printMSG("Error! Socket startup failed.");
		clearWSA();

		return -1;
	}

	system("pause");
	return 0;
}

